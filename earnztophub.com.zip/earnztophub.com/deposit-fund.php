<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<!-- font-family: 'Open Sans', sans-serif; -->
<link href="https://earnztophub.com/acct/styles/bootstrap.min.css" rel='stylesheet' type='text/css'>
<link href="https://earnztophub.com/acct/styles/custom.css" rel='stylesheet' type='text/css'>
<link href="https://earnztophub.com/acct/styles/default.css" rel='stylesheet' type='text/css'>
<link href="https://earnztophub.com/acct/styles/tab.css" rel='stylesheet' type='text/css'>
    <title>earnztophub | Deposit Method</title>
    <!--Favicon add-->
    <link rel="shortcut icon" type="image/png" href="https://earnztophub.com/images/logo.png">
<script src="https://earnztophub.com/acct/styles/jquery.js" type='text/javascript'></script>
<script src="https://earnztophub.com/acct/styles/setting2.js" type='text/javascript'></script>
<script src="https://earnztophub.com/acct/styles/tab.js" type='text/javascript'></script>
<script src="https://earnztophub.com/acct/styles/bootstrap.min.js" type='text/javascript'></script>

</head>
<body class="loginarea">
<div class="wrapper-account">
  <div class="headerContainer">
    <div class="headerInner"> <a href=""><img src="https://earnztophub.com/images/logo.png"></a>
      <div class="hdRight">
        <div class="mainNavRight">
          <div class="navbar">
            <div class="navbar-inner">
              <ul class="nav">
                <li><a href="https://earnztophub.com">Home</a></li>
                <li><a href="https://earnztophub.com/acct/about">About</a></li>
                <li><a href="https://earnztophub.com/acct/faqs">FAQ</a></li>
                <li><a href="https://earnztophub.com/acct/how-to">How to Start </a></li>
                <li><a href="https://earnztophub.com/acct/buybtc">where to buy/sale bitcoin</a></li>
                <li><a href="https://earnztophub.com/acct/affiliate">Affiliates</a></li>
                
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
 </div>

<div class="inside_inner_account">
<div class="member_wrap">
<div class="membersidebar">
<ul>
    <li><a href="dashboard.php">My Account</a></li>
    <li><a href="edit-profile.php ">Edit Account</a></li>
    <li><a href="deposit-fund.php">Deposits</a></li>
    <li><a href="deposit-history.php">Deposits History</a></li>
    <li><a href="withdraw-request.php ">Withdraw</a></li>
    <li><a href="withdraw-log.php ">Withdrawals History</a></li>
    <li><a href="dashboard.php">Referrals</a></li>
    <li><a href="logout.php">Logout</a></li>
</ul>
</div>
<div class="member-container">
<div class="account_top">
  <div class="user_left">
    <h2>Welcome, <span>italyyy</span></h2>
  </div>
  <div class="affiliate_top">Affiliate Link:<a href="https://earnztophub.com/register/italyyy" class="ref-link">https://earnztophub.com/register/italyyy</a></div>
  <div class="get_banners"><a href="https://earnztophub.com/user/dashboard">Get Banners</a></div>
</div>
             <div class="member_right">

 <center><h1>Send your bitcoin deposit to the address below:</h1><br><br>


<div style='background-color:#0000ff;' align='center'><font color='white' size='5'><b><strong>bc1q7c22mnta9haqhgnxyvawtz0t0l0fql0wujw24t</strong></b></font>
</div>
<br><br><font color='red' size='5'><marquee>Ensure to copy address properly to avoid payment error
</marquee></font>
</div><!--end column-70-->
</div>
</div>
</div>

</div>
         <div class="contentBotContainer">
  <div class="contentBotInner">
    <div class="ctn-top-solid">
      <h1>btc network </h1>
      <h2> wallets: </h2>
      <div class="solid-top">
		  <a href="https://www.coinbase.com/" class="solidTop1"></a> 
		  <a href="https://blockchain.info/" class="solidTop2"></a>
		  <a href="https://xapo.com/" class="solidTop3"></a>
		  <a href="https://airbitz.co/" class="solidTop4"></a>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="ctn-bot-solid">
      <p>Market Cap: <span>$77829716960.00</span></p>
      <p>Hashrate: <span>7108353254.76</span></p>
      <p>Difficulty: <span>888171856257</span></p>
      <p>Total Blocks: <span>482882</span> </p>
      <p>Network Speed: <span>108.5 PH/s</span></p>
    </div>
  </div>
</div>
<script src="//code.tidio.co/skldbcr5zdkdy8lt1nvom4bojetjjqqn.js" async></script>

<div class="footerContainer">
	<div class="footerInner">
		<div class="ctn-footer-top">
			<div class="ctn-ft-left">
				<p>&copy; Copyright ©  2023 earnztophub. All Right Reserved.</p>
			</div>
			<div class="ctn-ft-mid">
				<a href=""><img src="https://earnztophub.com/images/logo.png"></a>
			</div>
			<div class="ft-solid">
				<a href="https://www.facebook.com/VisualHyipcom/" target="_blank" class="per"></a>
				<a href="https://twitter.com/" target="_blank" class="bit"></a>
				
			</div>
			<div class="ctn-ft-right">
				<ul>
					<li><a href="?a=rules">TERMS OF SERVICES</a></li>
					<li><a href="?a=faq">FAQ</a></li>
					<li><a href="?a=news">NEWS</a></li>
					<li><a href="?a=support">CONTACT US</a></li>
				</ul>
			</div>
		</div>
	</div>
</div> <!-- end bot footer -->
	
	<script type="text/javascript">
$(document).ready(function() {

		$('.accordion>dl>dt>a').click(function() 
		{
			$(this).toggleClass("rotate0");
		});
			/*------- parse price --------*/
			function parsePriceCrypto()
			{
				returnString = "";
				
				$.post( "https://min-api.cryptocompare.com/data/pricemulti?fsyms=BTC,LTC,ETH,BCH,XRP&tsyms=USD", function( data )
				{
					$('#price_btc').text('$'+data['BTC']['USD']);
					$('#price_ltc').text('$'+data['LTC']['USD']);
					$('#price_eth').text('$'+data['ETH']['USD']);
					$('#price_bch').text('$'+data['BCH']['USD']);
					$('#price_xrp').text('$'+data['XRP']['USD']);
				});
			}
			parsePriceCrypto();
			
			setInterval(function()
			{
				parsePriceCrypto();
			}
			, 5000);
		});
		
		$('.language').click(function() {
			$(this).toggleClass('active');
		});
		
		$('.mobileMenu').click(function() {
			$('.menu').toggleClass('mobile');
			$(this).toggleClass('rotate');
		});


	</script> 
	<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ed679239e5f6944228fbc26/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</body>
</html>
