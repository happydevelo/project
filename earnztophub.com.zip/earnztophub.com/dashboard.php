<!doctype html>
<html class="no-js">

<!-- Mirrored from essentialminingfxtrade.com.com/main/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 18 Sep 2021 21:18:13 GMT -->
<!-- Added by HTTrack -->
<!-- Mirrored from essentialminingfxtrade.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 19 Apr 2022 15:16:33 GMT -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="favicon.png" rel="icon" type="image/x-icon" />
	<!-- Add icon library -->
	<link rel="stylesheet" href="cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.html">

	<link href="css/main.css" rel="stylesheet" />
	<link href="css/animate.min.css" rel="stylesheet" />

	<title>Earn Top Hub</title>
	<link rel="manifest" href="js/manifest.json">
	<meta name="theme-color" content="#00a9e0">
	<meta name="msapplication-navbutton-color" content="#00a9e0">
	<!-- iOS Safari -->
	<meta name="apple-mobile-web-app-status-bar-style" content="#00a9e0">


	<meta name="theme-color" content="#00a9e0">
	<meta name="msapplication-navbutton-color" content="#00a9e0">
	<!-- iOS Safari -->
	<meta name="apple-mobile-web-app-status-bar-style" content="#00a9e0">

	<link href="favicon.png" rel="icon" type="image/x-icon" />
	<link rel="icon" sizes="192x192" href="404.html">

	<meta name="keywords" content="Earn Top Hub" />
	<meta property="og:image" content="images/icon/icon-310x310.png" />

	<meta name="msapplication-square310x310logo" content="images/icon/icon-310x310.png">
	<meta name="msapplication-square70x70logo" content="images/icon/icon-70x70.png">
	<meta name="msapplication-square150x150logo" content="images/icon/icon-150x150.png">
	<meta name="msapplication-wide310x150logo" content="images/icon/icon-310x150.png">

	<link rel="apple-touch-icon-precomposed" href="images/icon/apple-touch-icon.png">
	<link rel="apple-touch-icon-precomposed" sizes="57x57" href="404.html" />
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="404.html" />
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/icon/apple-touch-icon-114x114.png" />
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/icon/apple-touch-icon-144x144.png" />

  
	<meta property="og:site_name" content="Earn Top Hub">
	<meta property="og:title" content="Earn Top Hub" />
	<meta name="description"
		content="Earn Top Hub Investment Company is a distinctive investment company offering our investors access to high-growth investment opportunities in Bitcoin markets and other services. We implement best practices of trading &amp; mining of Bitcoins through our operations, while offering flexibility in our investment plans. Our company benefits from an extensive network of global clients.">
	<meta property="og:description"
		content="Earn Top Hub Investment Company is a distinctive investment company offering our investors access to high-growth investment opportunities in Bitcoin markets and other services. We implement best practices of trading &amp; mining of Bitcoins through our operations, while offering flexibility in our investment plans. Our company benefits from an extensive network of global clients.">
	<meta property="og:type" content="website" />

	<script src="js/jquery.min.js"></script>
	<script src="js/jquery-ui.js"></script>
	<script src="js/jquery.form.js"></script>

	<link href="css/select2.min.css" rel="stylesheet" />
	<script>
		$(document).ready(function () {
			function close_accordion_section() {
				$('.accordion .accordion-section-title').removeClass('active');
				$('.accordion .accordion-section-content').slideUp(300).removeClass('open');
			}

			$('.accordion-section-title').click(function (e) {
				// Grab current anchor value
				var currentAttrValue = $(this).attr('href');

				if ($(e.target).is('.active')) {
					close_accordion_section();
				} else {
					close_accordion_section();

					// Add active class to section title
					$(this).addClass('active');
					// Open up the hidden content panel
					$('.accordion ' + currentAttrValue).slideDown(300).addClass('open');
				}

				e.preventDefault();
			});
		});
	</script>
	<script>
		var fade_outthis = function () {
			$(".alert").fadeOut().empty();
		}
		setTimeout(fade_outthis, 8000);

		$(document).ready(function () {
			$(".closebtn").click(function () {
				$(this).parent().fadeOut().empty();
			});
		});
	</script>
	
	<script type="text/javascript">
    function googleTranslateElementInit() {
        new google.translate.TranslateElement({
            pageLanguage: 'en'
        }, 'google_translate_element');
    }
</script>
<script type="text/javascript" src="translate.google.com/translate_a/elementa0d8a0d8.html?cb=googleTranslateElementInit"></script>

<style type="text/css">
    .goog-logo-link {
        display: none !important;
    }

    .goog-te-gadget {
        color: transparent !important;
        border-color: transparent !important;
        background-color: transparent !important;
    }

    .goog-te-gadget .goog-te-combo {
        width: 150px;
        padding: 1px;
        font-family: inherit;
        font-weight: bold;
        color: whitesmoke !important;
        border-radius: 5px;
        font-size: 13px;
        border-color: transparent !important;
        background-color: #02518d !important;
    }
</style>

	   
</head>

<body class="loading_it">
    
     
	<header class="header">
		<script src="widgets.coingecko.com/coingecko-coin-price-marquee-widget.js"></script>
		<coingecko-coin-price-marquee-widget coin-ids="bitcoin,ethereum,eos,ripple,litecoin" currency="usd"
			background-color="#121212" locale="en" font-color="#c0c0c0"></coingecko-coin-price-marquee-widget>
		<div class="container row">
			<ul class="topheader">
				<li class="logo">
					<div class="bodycontainer">
						<button class="btn round default right menu"><i class="fa fa-align-right"></i></button>
						<a href="index.html">
							<img src="images/logo.png" title="Earn Top Hub" />
						</a>
						<a style="margin:auto; text-align:center" id="google_translate_element"></a>
					</div>
				</li>
				<li class="data">
					<div class="bodycontainer">
						<ul>
							<li>
								<div id="google_translate_element"></div>
							</li>
							<li>
								<div>+5.26%</div>24 hour price
							</li>
							<li>
								<div>12.820 BTC</div>24 hour volume
							</li>
							<li>
								<div>69,775</div>active traders
							</li>
							<li>
								<div class="btcwdgt-price" bw-cur="usd"></div>Live Bitcoin price
							</li>
						</ul>
					</div>
				</li>
				<li class="account row">
					<div class="bodycontainer">
						<div class="button_container"><a href="acct/login.php" class="btn"><i class="fa fa-user"></i> SIGN
								IN</a></div>
						<div class="button_container"><a href="acct/register.php" class="btn v2"><i
									class="fa fa-user-plus"></i> REGISTER</a></div>
					</div>
				</li>
			</ul>
		</div>
	</header>
	<nav class="center">
		<div class="bodycontainer">
			<ul>
				<li><a href="index.html" class="active">HOME</a></li>
				<li><a href="info/about.html">ABOUT US</a></li>
				<li><a href="index-2.html#investment">INVESTMENT PLANS</a></li>
				<li><a href="#">LEGAL <i class="fa fa-chevron-down"></i></a>
					<ul>
						<li><a href="info/terms.html">TERMS & CONDITIONS</a></li>
						<li><a href="faqs/index.html">FAQS</a></li>
					</ul>
				</li>
				<li><a href="contact/index.html">CONTACT US</a></li>
				<li><a href="affiliate_program/index.html">AFFILIATE</a></li>
			</ul>
		</div>
	</nav>
	<script>
		$(".menu").click(function () {
			$("nav").slideToggle();
		});
	</script>

	<div class="preloader">
		<div id="bitcoin">
			<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg"
				xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="200px" height="200px"
				viewBox="100 100 400 400" xml:space="preserve">
				<filter id="dropshadow" height="130%">
					<feGaussianBlur in="SourceAlpha" stdDeviation="5" />
					<feOffset dx="0" dy="0" result="offsetblur" />
					<feFlood flood-color="red" />
					<feComposite in2="offsetblur" operator="in" />
					<feMerge>
						<feMergeNode />
						<feMergeNode in="SourceGraphic" />
					</feMerge>
				</filter>
				<path class="path" style="filter:url(#dropshadow)" fill="#000000" d="M446.089,261.45c6.135-41.001-25.084-63.033-67.769-77.735l13.844-55.532l-33.801-8.424l-13.48,54.068
	c-8.896-2.217-18.015-4.304-27.091-6.371l13.568-54.429l-33.776-8.424l-13.861,55.521c-7.354-1.676-14.575-3.328-21.587-5.073
	l0.034-0.171l-46.617-11.64l-8.993,36.102c0,0,25.08,5.746,24.549,6.105c13.689,3.42,16.159,12.478,15.75,19.658L208.93,357.23
	c-1.675,4.158-5.925,10.401-15.494,8.031c0.338,0.485-24.579-6.134-24.579-6.134l-9.631,40.468l36.843,9.188
	c8.178,2.051,16.209,4.19,24.098,6.217l-13.978,56.17l33.764,8.424l13.852-55.571c9.235,2.499,18.186,4.813,26.948,6.995
	l-13.802,55.309l33.801,8.424l13.994-56.061c57.648,10.902,100.998,6.502,119.237-45.627c14.705-41.979-0.731-66.193-31.06-81.984
	C425.008,305.984,441.655,291.455,446.089,261.45z M368.859,369.754c-10.455,41.983-81.128,19.285-104.052,13.589l18.562-74.404
	C306.28,314.65,379.774,325.975,368.859,369.754z M379.302,260.846c-9.527,38.187-68.358,18.781-87.442,14.023l16.828-67.489
	C327.767,212.14,389.234,221.02,379.302,260.846z" />

			</svg>
		</div>
	</div>
	<script>
		/*--window load functions--*/
		jQuery(window).load(function () {
			var preLoder = $(".preloader");
			preLoder.fadeOut(1000);
			$("body").removeClass("loading_it");
		});
	</script>
	<style>
		body {
			top: 0 !important;
		}
	</style>
	<script>
		$(function () {
			$("#tabs").tabs();
		});
	</script>
	<link rel="stylesheet" type="text/css" href="slick/slick.css">
	<link rel="stylesheet" type="text/css" href="slick/slick-theme.css">
	<style>
		.slick-dots {
			bottom: -10px !important;
		}

		.slick-dotted.slick-slider {
			margin-bottom: 0px;
		}
	</style>
	<div class="Modern-Slider row center">
		<!-- Item -->
		<div class="item">
			<div class="img-fill">
				<img src="images/912465.jpg" alt="">
				<div class="info-slick">
					<div>
						<h1 class="headering"><span class="text-default">SECURE</span> AND <span
								class="text-default">EASY WAY</span><br>TO CRYPTO TRADE</h1>
						<a href="get-started/index.html" class="btn">LEARN MORE</a>
					</div>
				</div>
			</div>
		</div>
		<!-- // Item -->
		<!-- Item -->
		<div class="item">
			<div class="img-fill">
				<img src="images/913441.jpg" alt="">
				<div class="info-slick">
					<div>
						<h1 class="headering"><span class="text-default">BITCOIN</span> INVESTMENT<br>YOU CAN <span
								class="text-default">TRUST</span></h1>
						<a href="get-started/index.html" class="btn">GET STARTED</a>
					</div>
				</div>
			</div>
		</div>
		<!-- // Item -->
	</div>
	<script src="js/jquery.fittext.js"></script>
	<script>
		$(".headering").fitText(1.3, { minFontSize: 35 });
	</script>
	<div class="dark">
		<div class="bodycontainer" style="padding:0 30px">
			<div class="row" style="background: #1D1D1D; top: -40px; position: relative; text-align: left;">
				<div class="col-4">
					<div class="col-3 col-m-4 center">
						<img src="images/download-bitcoin.png">
					</div>
					<div class="col-9 col-m-8 center-sm">
						<h5 class="text-white">Download Bitcoin Wallet</h5>
						<p>Get it on PC or Mobile to create, send and receive bitcoins.</p>
					</div>
				</div>
				<div class="col-4">
					<div class="col-3 col-m-4 center">
						<img src="images/add-bitcoins.png">
					</div>
					<div class="col-9 col-m-8 center-sm">
						<h5 class="text-white">Add Funds & Start Investment</h5>
						<p>Add bitcoins you’ve created or exchanged via credit card.</p>
					</div>
				</div>
				<div class="col-4">
					<div class="col-3 col-m-4 center">
						<img src="images/buy-sell-bitcoins.png">
					</div>
					<div class="col-9 col-m-8 center-sm">
						<h5 class="text-white">Withdraw Your Profit</h5>
						<p>Request for withdrawal and receive it within 1day.</p>
					</div>
				</div>
			</div>
			<div class="center">
				<h1 class="tlt text-white">ABOUT <span class="text-default">US</span></h1>
				<p class="sub_tlt">MOST FLEXIBLE CRYPTOCURRENCY INVESTMENT COMPANY</p>
			</div>

			<div class="row" style="margin-top: 20px">
				<div class="col-6 center">
					<img src="images/about-us.png">
				</div>
				<div class="col-6">
					<h2 class="text-white">WE ARE Earn Top Hub</h2>
					<p>Earn Top Hub Investment Company is a distinctive investment company offering our investors
						access to high-growth investment opportunities in Bitcoin markets and other services. We
						implement best practices of trading & mining of Bitcoins through our operations, while offering
						flexibility in our investment plans. Our company benefits from an extensive network of global
						clients.</p>
					<div id="tabs" style="margin-bottom: 20px">
						<ul>
							<li><a href="#tabs-1">OUR MISSION</a></li>
							<li><a href="#tabs-2">OUR ADVANTAGES</a></li>
							<li><a href="#tabs-3">OUR GUARANTEES</a></li>
						</ul>
						<div id="tabs-1">
							<p>Our aim is to utilize our expertise & knowledge which will benefit our clients and the
								users of our services.</p>
						</div>
						<div id="tabs-2">
							<p>Our mission as an official partner of Bitcoin Foundation is to help you enter and better
								understand the world of #1 cryptocurrency and avoid any issues you may encounter.</p>
						</div>
						<div id="tabs-3">
							<p>We are here because we are passionate about open, transparent markets and aim to be a
								major driving force in widespread adoption, we are one the bests in cryptocurrency
								investment.</p>
						</div>
					</div>
					<a href="info/about.html" class="btn default">READ MORE</a>
				</div>
			</div>
		</div>
	</div>

	<div class="darkgrey">
		<div class="bodycontainer-left">
			<div class="row lineup">
				<div class="col-8 center">
					<div class="col-6 col-m-6">
						<div><img src="images/strong-security.png" style="height:40px"></div>
						<h5 class="text-white">STRONG SECURITY</h5>
						<p>Protection against DDoS attacks,<br>full data encryption</p>
					</div>
					<div class="col-6 col-m-6">
						<div><img src="images/world-coverage.png" style="height:40px"></div>
						<h5 class="text-white">WORLD COVERAGE</h5>
						<p>Providing services in 99% countries<br>around all the globe</p>
					</div>
					<div class="col-6 col-m-6">
						<div><img src="images/payment-options.png" style="height:40px"></div>
						<h5 class="text-white">PAYMENT OPTIONS</h5>
						<p>Popular methods: Bitcoin, Ethereum,<br>Stellar</p>
					</div>
					<div class="col-6 col-m-6">
						<div><img src="images/mobile-app.png" style="height:40px"></div>
						<h5 class="text-white">MOBILE FRIENDLY</h5>
						<p>Our User Dashboard is Made<br>to match all Mobile resultions</p>
					</div>
					<div class="col-6 col-m-6">
						<div><img src="images/cost-efficiency.png" style="height:40px"></div>
						<h5 class="text-white">COST EFFICIENCY</h5>
						<p>Reasonable trading fees for takers<br>and all market makers</p>
					</div>
					<div class="col-6 col-m-6">
						<div><img src="images/high-liquidity.png" style="height:40px"></div>
						<h5 class="text-white">HIGH LIQUIDITY</h5>
						<p>Fast access to high liquidity orderbook<br>for top currency pairs</p>
					</div>
				</div>
				<div class="col-4 video-lightbox">
					<a href="#" class="play circle js-video-button" data-video-id="GmOzih6I1zs"><i
							class="fa fa-play"></i></a>
				</div>
			</div>
		</div>
	</div>
	<script src="js/jquery-modal-video.min.js"></script>
	<link rel="stylesheet" href="css/modal-video.min.css">
	<script>
		$(".js-video-button").modalVideo();
	</script>
	<div class="dark" style="padding: 40px 20px 80px 20px" id="investment">
		<div class="bodycontainer center">
			<h1 class="tlt text-white">AFFORDABLE <span class="text-default">PACKAGES</span></h1>
			<p class="sub_tlt">CHOOSE YOUR PREFERABLE PLAN FOR INVESTMENT.</p>
			<div class="row margint">
				<div class="col-3 col-m-12">
					<div class="pricing_body">
						<ul>
							<li>INVEST INTO</li>
							<li style="text-transform: uppercase;">Basic Plan</li>
							<li class="pricing_info">STARTING AT</li>
							<li class="pricing_amount margintb">$200 - $3,000</li>
						</ul>
						<a href="acct/register.php" class="btn default margint">Invest Now</a>
					</div>
				</div>
				<div class="col-3 col-m-12">
					<div class="pricing_body">
						<ul>
							<li>INVEST INTO</li>
							<li style="text-transform: uppercase;">Standard Plan</li>
							<li class="pricing_info">STARTING AT</li>
							<li class="pricing_amount margintb">$3,100 - $10,000</li>
						</ul>
						<a href="acct/register.php" class="btn default margint">Invest Now</a>
					</div>
				</div>
				<div class="col-3 col-m-12">
					<div class="pricing_body">
						<ul>
							<li>INVEST INTO</li>
							<li style="text-transform: uppercase;">Executive Plan</li>
							<li class="pricing_info">STARTING AT</li>
							<li class="pricing_amount margintb">$10,000 - $20,000</li>
						</ul>
						<a href="acct/register.php" class="btn default margint">Invest Now</a>
					</div>
				</div>
				<div class="col-3 col-m-12">
					<div class="pricing_body">
						<ul>
							<li>INVEST INTO</li>
							<li style="text-transform: uppercase;">Premium  Plan</li>
							<li class="pricing_info">STARTING AT</li>
							<li class="pricing_amount margintb">$20,000 - Unlimited</li>
						</ul>
						<a href="acct/register.php" class="btn default margint">Invest Now</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Blog Section Starts -->
      
        <!-- Section Title Starts -->
       <div class="dark container">
            <div class="row">
                <h1 class="tlt text-white">Certifications</h1>
    			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
    				<div class="title-head-subtitle">
    					<img style="text-align:center; padding: 0 40px 0 40px;" height="40%" width="40%" src="images/certificate.png" class="img-responsive" alt="team member">
    				
    					<img style="text-align:center; float:left; padding: 0 40px 0 40px;" height="40%" width="40%" src="images/tradecertificate.png" class="img-responsive" alt="team member">
    				</div>
    			</div>
            </div>
       </div>
        <!-- Section Title Ends -->
        
    <!-- Blog Section Ends -->
	<style>
		.irs-single,
		.irs-min,
		.irs-max {
			display: none !important;
		}

		.irs-bar {
			border-top: 1px solid #00a9e0 !important;
			border-bottom: 1px solid #00a9e0 !important;
			background: #00a9e0 !important;
		}

		.irs-bar-edge {
			border: 1px solid #00a9e0 !important;
			background: #00a9e0 !important;
			background: #00a9e0 !important;
		}

		.irs-slider {
			border: 3px solid #AAA !important;
			background: #00a9e0 !important;
		}
	</style>
	<link rel="stylesheet" href="css/ion.rangeSlider.css">
	<link rel="stylesheet" href="css/ion.rangeSlider.skinHTML5.css">
	<script src="js/ion.rangeSlider.min.js"></script>
	<script>
		var $range = $(".range_47");
		$range.ionRangeSlider();

		$range.on("change", function () {
			var $this = $(this),
				value = $this.prop("value");
			var output = $this.prop("value") * ($this.data("cent") / 100);
			$("#" + $this.data("id")).val("$ " + $this.prop("value"));
			$("#" + $this.data("per")).html("$ " + output.toFixed(1));
			$("#" + $this.data("total")).html("$ " + (output * $this.data("times")).toFixed(1));
			console.log("Value: " + value);
		});
	</script>
	<div class="calculator-container" style="position: relative; top: -50px; margin-bottom: -50px;">
		<div class="bodycontainer center" style="padding: 0 20px">
			<form class="bitcoin-calculator round-large	cards" id="bitcoin-calculator">
				<h1 class="tlt text-white"><span class="text-default">BITCOIN</span> CALCULATOR</h1>
				<p style="margin: 20px 0; font-size: 14px">FIND OUT THE CURRENT BITCOIN VALUE WITH OUR EASY-TO-USE
					CONVERTER</p>
				<div style="margin: 20px 0">
					<!-- Input #1 Starts -->
					<input class="form-input" name="btc-calculator-value" value="1">
					<!-- Input #1 Ends -->
					<div class="form-info"><i class="fa fa-bitcoin"></i></div>
					<div class="form-equal">=</div>
					<!-- Input/Result Starts -->
					<input class="form-input form-input-result" name="btc-calculator-result">
					<!-- Input/Result Ends -->
					<!-- Select Currency Starts -->
					<div class="form-wrap">
						<select id="currency-select"
							class="form-input select-currency select-primary select2-hidden-accessible"
							name="btc-calculator-currency" data-dropdown-class="select-primary-dropdown" tabindex="-1"
							aria-hidden="true">
							<option value="0">USD</option>
							<option value="1">AUD</option>
							<option value="2">BRL</option>
							<option value="3">CAD</option>
							<option value="4">CHF</option>
							<option value="5">CLP</option>
							<option value="6">CNY</option>
							<option value="7">DKK</option>
							<option value="8">EUR</option>
							<option value="9">GBP</option>
							<option value="10">HKD</option>
							<option value="11">INR</option>
							<option value="12">ISK</option>
							<option value="13">JPY</option>
							<option value="14">KRW</option>
							<option value="15">NZD</option>
							<option value="16">PLN</option>
							<option value="17">RUB</option>
							<option value="18">SEK</option>
							<option value="19">SGD</option>
							<option value="20">THB</option>
							<option value="21">TWD</option>
						</select>
					</div>
					<!-- Select Currency Ends -->
				</div>
				<p><i>* Data updated every 15 minutes</i></p>
			</form>
		</div>
		<div class="bitcoin-calculator-bg"></div>
	</div>
	<style>
		.btcwdgt.btcwdgt-chart .btcwdgt-footer {
			display: none !important;
		}

		.btcwdgt-headlines.btcwdgt-clean {
			margin: 0 auto !important;
			border: 1px solid #333 !important;
			box-shadow: none !important;
			max-width: 615px !important;
			width: 100%;
		}
	</style>
	<div class="dark">
		<div class="row lineup">
			<div class="col-4 col-m-12 testimony-lightbox">
				<div class="bodycontainer center-mode" style="position: relative">

					<ul class="testimonials" style="padding: 40px 20px">No results found</ul>
				</div>
			</div>
			<div class="col-8 col-m-12 center">
				<div class="bodycontainer">
					<div class="btcwdgt-chart" bw-theme="dark" style="width:100%"></div>
				</div>
			</div>
		</div>
	</div>

	<script src="widgets.bitcoin.com/widget.js" id="btcwdgt"></script>
	<script src="js/select2.min.js"></script>
	<script>
		/* ----------------------------------------------------------- */
		/*  VARIABLES FOR SELECT INPUT AND BITCOIN CALCULATOR FORM
		/* ----------------------------------------------------------- */

		var userAgent = navigator.userAgent.toLowerCase(),
			plugins = {
				selectFilter: $("#currency-select"),
				btcCalculator: $("#bitcoin-calculator"),
			};


		/* ----------------------------------------------------------- */
		/*  REPLACE OLD SELECT IN BITCOIN CALCULATOR FORM
		/* ----------------------------------------------------------- */

		if (plugins.selectFilter.length) {
			for (var i = 0; i < plugins.selectFilter.length; i++) {
				var select = $(plugins.selectFilter[i]);
				select.select2({
					placeholder: select.attr("data-placeholder") ? select.attr("data-placeholder") : false,
					minimumResultsForSearch: select.attr("data-minimum-results-search") ? select.attr("data-minimum-results-search") : 10,
					maximumSelectionSize: 3,
					dropdownCssClass: select.attr("data-dropdown-class") ? select.attr("data-dropdown-class") : ""
				});
			}
		}

		/* ----------------------------------------------------------- */
		/*  BITCOIN CALCULATOR [ WWW.BLOCKCHAIN.INFO API ]
		/* ----------------------------------------------------------- */

		if (plugins.btcCalculator.length) {

			$.getJSON("https://blockchain.info/ticker", function (btcJsonData) {
				var currencyList = [];
				var index = 0;

				for (var currency in btcJsonData) {
					currencyList.push({
						"id": index,
						"text": currency
					});
					index++;
				}

				for (var i = 0; i < plugins.btcCalculator.length; i++) {
					var btcForm = $(plugins.btcCalculator[i]),
						btcFormInput = $(btcForm.find('[name="btc-calculator-value"]')),
						btcFormOutput = $(btcForm.find('[name="btc-calculator-result"]')),
						btcFormCurrencySelect = $(btcForm.find('[name="btc-calculator-currency"]'));

					btcFormCurrencySelect.select2({
						placeholder: btcFormCurrencySelect.attr("data-placeholder") ? btcFormCurrencySelect.attr("data-placeholder") : false,
						minimumResultsForSearch: btcFormCurrencySelect.attr("data-minimum-results-search") ? btcFormCurrencySelect.attr("data-minimum-results-search") : 50,
						maximumSelectionSize: 3,
						dropdownCssClass: btcFormCurrencySelect.attr("data-dropdown-class") ? btcFormCurrencySelect.attr("data-dropdown-class") : '',
						data: currencyList
					});

					if (btcFormInput.length && btcFormOutput.length) {
						// BTC => Currency
						(function (btcFormInput, btcFormOutput, btcFormCurrencySelect) {
							var lastChanged = 'btc';

							btcFormInput.on('input', function () {
								// store current positions in variables
								var selectionStart = this.selectionStart,
									selectionEnd = this.selectionEnd;

								this.value = toCryptoCurrencyFormat(this.value);

								// restore cursor position
								this.setSelectionRange(selectionStart, selectionEnd);

								btcFormOutput.val(toCurrencyFormat('' + btcJsonData[btcFormCurrencySelect.select2('data')[0].text]["buy"] * this.value));
								lastChanged = 'btc';
							});

							// Currency => BTC
							btcFormOutput.on('input', function () {
								// store current positions in variables
								var selectionStart = this.selectionStart,
									selectionEnd = this.selectionEnd;

								this.value = toCurrencyFormat(this.value);

								// restore cursor position
								this.setSelectionRange(selectionStart, selectionEnd);

								btcFormInput.val(toCryptoCurrencyFormat('' + this.value / btcJsonData[btcFormCurrencySelect.select2('data')[0].text]["sell"]));
								lastChanged = 'currency';
							});

							btcFormInput.trigger('input');
							btcFormOutput.blur();

							btcFormCurrencySelect.on('change', function () {
								if (lastChanged === 'btc') {
									btcFormOutput.val(toCurrencyFormat('' + btcJsonData[btcFormCurrencySelect.select2('data')[0].text]["buy"] * btcFormInput.val()));
								} else {
									btcFormInput.val(toCryptoCurrencyFormat('' + btcFormOutput.val() / btcJsonData[btcFormCurrencySelect.select2('data')[0].text]["sell"]));
								}
							});
						})(btcFormInput, btcFormOutput, btcFormCurrencySelect);
					}
				}
			})
				.fail(function () {
					console.log('Error while fetching data from https://blockchain.info/ticker');
				});
		}

		function toCurrencyFormat(stringValue) {
			var value = parseFloat(stringValue.replace(/[^\d.]/g, '')).toFixed(2);
			return $.isNumeric(value) ? value : 0;
		}

		function toCryptoCurrencyFormat(stringValue) {
			var value = stringValue.replace(/[^\d.]/g, '');
			return $.isNumeric(value) ? value : 0;
		}

	</script>

	<script src="slick/slick.js" type="text/javascript" charset="utf-8"></script>
	<script src="slick/slick-animation.min.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript">
		// Init slick slider + animation
		$(document).ready(function () {

			$(".Modern-Slider").slick({
				autoplay: true,
				autoplaySpeed: 10000,
				speed: 600,
				slidesToShow: 1,
				slidesToScroll: 1,
				pauseOnHover: false,
				dots: false,
				pauseOnDotsHover: true,
				cssEase: 'linear',
				// fade:true,
				draggable: false,
				prevArrow: '<button class="PrevArrow"></button>',
				nextArrow: '<button class="NextArrow"></button>',
			});
			$(".testimonials").slick({
				autoplay: true,
				autoplaySpeed: 10000,
				speed: 600,
				slidesToShow: 1,
				slidesToScroll: 1,
				pauseOnHover: false,
				dots: false,
				arrows: false,
				adaptiveHeight: true
			});

		})
	</script>
	<style>
		.btcwdgt-chart .btcwdgt-header {
			background-color: #00a9e0 !important;
		}

		.btcwdgt-chart .btcwdgt-header h2 {
			background-color: #00a9e0 !important;
		}

		.btcwdgt-chart .btcwdgt-header .stats div,
		.btcwdgt-chart .btcwdgt-header h4 {
			color: #F7EADC !important;
		}
	</style>
	<a href="#" id="back-to-top" class="back-to-top fa fa-arrow-up show-back-to-top"></a>

	<script>
		/*--window Scroll functions--*/
		$(window).on('scroll', function () {
			/*--show and hide scroll to top --*/
			var ScrollTop = $('#back-to-top');
			if ($(window).scrollTop() > 500) {
				ScrollTop.fadeIn(1000);
			} else {
				ScrollTop.fadeOut(1000);
			}
		});
	</script>
	<div class="footer_bg center">
		<div class="area">
			<div class="bodycontainer">
				<div style="z-index:2; position: relative">
					<h2 class="margintb">GET STARTED TODAY WITH BITCOIN INVESTMENT</h2>
					<p class="margintb">Open account for free and start trading Bitcoins!</p>
					<a href="get-started/index.html" class="btn">GET STARTED</a>
				</div>
			</div>
		</div>
	</div>
	
	
	
	<footer>
		<div class="bodycontainer">
			<div class="row">
				<div class="col-2 col-m-4 col-sm-12">
					<div class="padding">
						<h3>QUICK LINKS</h3>
						<ul>
							<li><a href="index.html">Home</a></li>
							<li><a href="info/about.html">About Us</a></li>
							<li><a href="faqs/index.html">FAQS</a></li>
							<li><a href="info/terms.html">TERMS AND CONDITIONS</a></li>
							<li><a href="contact/index.html">CONTACT US</a></li>
						</ul>
					</div>
				</div>
				<div class="col-2 col-m-4 col-sm-12">
					<div class="padding">
						<h3>HELP & SUPPORT</h3>
						<ul>
							<li><a href="https://cointelegraph.com/bitcoin-for-beginners/what-are-cryptocurrencies"
									target="_blank">WHAT IS BITCOIN?</a></li>
							<li><a href="https://www.investopedia.com/tech/how-to-buy-bitcoin/" target="_blank">HOW TO
									BUY BITCOIN</a></li>
							<li><a href="acct/register.php">REGISTER</a></li>
							<li><a href="acct/login.php">LOGIN</a></li>
							<li><a href="fpass.html">FORGOT PASSWORD</a></li>
						</ul>
					</div>
				</div>
				<div class="col-3 col-m-4 col-sm-12">
					<div class="padding">
						<h3>CONTACT US</h3>
						<a href="mailto://info@earnztophub.com">
							<h3 style="font-size:12px;">info@earnztophub.com</h3>
						</a>
						<ul>
							<li>MON-SAT 08AM ⇾ 05PM</li>
							<ul class="social">
								<li><a href="#" class="circle"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#" class="circle"><i class="fa fa-twitter"></i></a></li>
							</ul>
							<div class="margint">Language:</div>
						</ul>
					</div>
				</div>
				<div class="col-5 col-m-12 col-sm-12">
					<div class="col-6 col-m-6 col-sm-6" style="padding-bottom:0">
						<div class="value">$198.76B</div>
						MARKET CAP
						<div class="value">69K+</div>
						ACTIVE ACCOUNTS
					</div>
					<div class="col-6 col-m-6 col-sm-6" style="padding-bottom:0">
						<div class="value">243K</div>
						WEEKLY TRANSACTIONS
						<div class="value">127</div>
						SUPPORTED COUNTRIES
					</div>
					<div class="col-12" style="padding-top:0">
						<hr>
						SUPPORTED PAYMENT METHODS<br>
						<img src="images/5b55bb652af1a.png" style="width:40px">
						<img src="images/1532345051h7.png" style="width:40px">
						<img src="images/54563677267783.png" style="width:40px">
					</div>
				</div>
			</div>
			<hr>
			<p class="center">Copyright © 2023 Earn Top Hub (CFXTM), All Rights Reserved</p>
		</div>
	     <!-- ========== START COPYING HERE ========== -->
	       <link rel="stylesheet" href="alert/css/fake-notification-min.css">
             <link rel="stylesheet" href="alert/css/animate.min.css">
             <link rel="stylesheet" href="alert/css/font-awesome.min.css">
      <div id="notification-1" class="notification">      
        <div class="notification-block">
          <div class="notification-img">
            <!-- Your image or icon -->
          
            <i class="fa fa-user" aria-hidden="true"></i>
            <!-- / Your image or icon -->
          </div>
          <div class="notification-text-block">
            <div class="notification-title">
              <!-- Notification Title -->
              Earnings
              <!-- / Notification Title -->
            </div>
            <div class="notification-text"></div>
          </div>
        </div>
      </div>
      
      <!-- ========== END COPYING HERE ========== -->
	</footer>
	<script src="js/particle.js"></script>
	<script>
		particlesJS("particles-js", {
			"particles": { "number": { "value": 100, "density": { "enable": true, "value_area": 800 } }, "color": { "value": "#ffffff" }, "shape": { "type": "circle", "stroke": { "width": 0, "color": "#000000" }, "polygon": { "nb_sides": 5 }, "image": { "src": "img/github.svg", "width": 100, "height": 100 } }, "opacity": { "value": 0.5, "random": false, "anim": { "enable": false, "speed": 1, "opacity_min": 0.1, "sync": false } }, "size": { "value": 3, "random": true, "anim": { "enable": false, "speed": 40, "size_min": 0.1, "sync": false } }, "line_linked": { "enable": true, "distance": 150, "color": "#ffffff", "opacity": 0.4, "width": 1 }, "move": { "enable": true, "speed": 6, "direction": "none", "random": false, "straight": false, "out_mode": "out", "bounce": false, "attract": { "enable": false, "rotateX": 600, "rotateY": 1200 } } }, "interactivity": {
				"detect_on": "canvas", "events": { "onhover": { "enable": true, "mode": "repulse" }, "onclick": { "enable": true, "mode": "push" }, "resize": true }, "modes": { "grab": { "distance": 400, "line_linked": { "opacity": 1 } }, "bubble": { "distance": 400, "size": 40, "duration": 2, "opacity": 8, "speed": 3 }, "repulse": { "distance": 200, "duration": 0.4 }, "push": { "particles_nb": 4 }, "remove": { "particles_nb": 2 } }
			}, "retina_detect": true
		});
	</script>
	<script>
		(function (b, i, t, C, O, I, N) {
			window.addEventListener('load', function () {
				if (b.getElementById(C)) return;
				I = b.createElement(i), N = b.getElementsByTagName(i)[0];
				I.src = t; I.id = C; N.parentNode.insertBefore(I, N);
			}, false)
		})(document, 'script', 'widgets.bitcoin.com/widget.js', 'btcwdgt');
	</script>
	
	
	
	
	<!-- Fake Notifications jQuery plugin -->
	<script type="text/javascript" src="alert/js/jquery.fake-notification.min.js"></script>
	
	<!-- Fake Notifications invoke -->
	<script>
		$(document).ready(function() {
			$('#notification-1').Notification({
				// Notification varibles
				Varible1: ["Dirk", "Johnny", "Watkin ", "Alejandro",  "Vina",  "Tony",   "Ahmed","Jackson",  "Noah", "Aiden",  "Darren", "Isabella", "Aria", "John", "Greyson", "Peter", "Mohammed", "William",
				"Lucas", "Amelia", "Mason", "Mathew", "Richard", "Chris", "Mia", "Oliver"],
				Varible2: ["USA","UAE","Italy", "Florida",  "Mexico",  "India",  "China",  "Cambodia",  "United Kingdom",  "Germany", "Australia",  "Bangladesh", "Sweden", "Pakistan", "Maldives", "Seychelles", 
				"Bolivia",
				 "South Africa", "Zambia", "Zimbabwe", "Lebanese", "Saudi Arabia", "Chile", "Peuto Rico"],
				
				Amount: [100000,255555,55555,66666,44444,33333,333333],					
				Content: '[Varible1] from [Varible2] earned <b>$[Amount]</b>',
				// Timer
				Show: ['stable', 5, 10],
				Close: 5,
				Time: [0, 23],
				// Notification style 
				LocationTop: [true, '70%'],
				LocationBottom:[false, '10%'],
				LocationRight: [true, '10%'],						
				LocationLeft:[false, '10px'],
				Background: '#00000000',
				BorderRadius: 5,
				BorderWidth: 5,
				BorderColor: '#00000000',
				TextColor: 'white',
				IconColor: '#ffffff',
				// Notification Animated   
				AnimationEffectOpen: 'slideInUp',
				AnimationEffectClose: 'slideOutDown',
				// Number of notifications
				Number: 40,
				// Notification link
				Link: [true, 'index.html', '_blank']
				
			});		
			
			
		});				
		
	</script>
<script src="//code.tidio.co/skldbcr5zdkdy8lt1nvom4bojetjjqqn.js" async></script>


</body>


<!-- Mirrored from essentialminingfxtrade.com.com/main/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 18 Sep 2021 21:26:22 GMT -->

<!-- Mirrored from essentialminingfxtrade.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 19 Apr 2022 15:17:40 GMT -->
</html>